package com.university.lostfound.exception;

// Thrown when an external API call fails (Gemini, Cloudinary, etc.)
public class ApiException extends RuntimeException {

    public ApiException(String message) {
        super(message);
    }
}
