package com.university.lostfound.exception;

// Thrown when an item, user, or claim is looked up by id but doesn't exist
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
