package com.university.lostfound.service;

import com.university.lostfound.dto.ClaimRequest;
import com.university.lostfound.model.Claim;
import java.util.List;

public interface ClaimService {

    Claim createClaim(String itemId, String claimantId, ClaimRequest request);

    Claim approveClaim(String claimId);

    Claim rejectClaim(String claimId);

    List<Claim> findAll();
    List<Claim> findByItemId(String itemId);
    List<Claim> findByClaimantId(String claimantId);
}
