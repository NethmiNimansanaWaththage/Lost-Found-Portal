package com.university.lostfound.service;

import org.springframework.web.multipart.MultipartFile;

// Interface for uploading/deleting images via Cloudinary
public interface CloudinaryService {

    String upload(MultipartFile file);

    void delete(String publicId);
}
