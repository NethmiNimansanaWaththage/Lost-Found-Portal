package com.university.lostfound.service;

import com.university.lostfound.dto.AuthResponse;
import com.university.lostfound.dto.LoginRequest;
import com.university.lostfound.dto.RegisterRequest;
import com.university.lostfound.model.User;

// =========================================================================
// OOP CONCEPT: INTERFACES
// This interface declares WHAT a user-related service must be able to do,
// without saying HOW. UserServiceImpl provides the actual implementation.
// This keeps our code loosely coupled - controllers depend on this
// interface, not on a specific implementation.
// =========================================================================
public interface UserService {

    AuthResponse register(RegisterRequest request);

    AuthResponse login(LoginRequest request);

    User findById(String id);
}
