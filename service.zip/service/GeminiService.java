package com.university.lostfound.service;

import com.university.lostfound.dto.MatchResponse;

import java.util.List;

// Interface for all the AI-powered features backed by Google Gemini
public interface GeminiService {

    // Looks at a lost item's description and finds similar found items
    List<MatchResponse> findMatches(String lostItemId);

    // Uses Gemini to interpret a free-text search query
    List<MatchResponse> smartSearch(String query);

    // Improves/expands a short item description into a more detailed one
    String enhanceDescription(String description);
}
