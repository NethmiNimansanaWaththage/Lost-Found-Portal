package com.university.lostfound.service;

import com.university.lostfound.model.BaseItem;

import java.util.List;

// =========================================================================
// OOP CONCEPT: INTERFACES + POLYMORPHISM
// This single interface is implemented by BOTH LostItemService and
// FoundItemService. Each implementation provides its own version of
// save(), findById(), findAll(), and delete() - this is polymorphism:
// the same method names behave differently depending on which concrete
// service is actually being used.
//
// Generic type T extends BaseItem - because both LostItem and FoundItem
// extend BaseItem, this interface works for either one.
// =========================================================================
public interface ItemService<T extends BaseItem> {

    T save(T item);

    T findById(String id);

    List<T> findAll();

    void delete(String id);
}
