package com.university.lostfound.repository;

import com.university.lostfound.model.LostItem;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

// Talks to the "lost_items" collection in MongoDB
public interface LostItemRepository extends MongoRepository<LostItem, String> {

    // Find all lost items reported by a specific user
    List<LostItem> findByUserId(String userId);
}
