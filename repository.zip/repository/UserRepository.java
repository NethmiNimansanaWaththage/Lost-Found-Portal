package com.university.lostfound.repository;

import com.university.lostfound.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

// Talks to the "users" collection in MongoDB
public interface UserRepository extends MongoRepository<User, String> {

    // Used during login and registration to find a user by their email
    User findByEmail(String email);

    boolean existsByEmail(String email);
}
