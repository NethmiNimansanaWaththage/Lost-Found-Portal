package com.university.lostfound.repository;

import com.university.lostfound.model.Claim;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface ClaimRepository extends MongoRepository<Claim, String> {

    // Find all claims made on a specific item
    List<Claim> findByItemId(String itemId);

    // Find all claims submitted by a specific user
    List<Claim> findByClaimantId(String claimantId);
}