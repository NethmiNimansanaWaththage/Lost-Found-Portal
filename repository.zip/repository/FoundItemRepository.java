package com.university.lostfound.repository;

import com.university.lostfound.model.FoundItem;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

// Talks to the "found_items" collection in MongoDB
public interface FoundItemRepository extends MongoRepository<FoundItem, String> {

    // Find all found items reported by a specific user
    List<FoundItem> findByUserId(String userId);
}
