package com.university.lostfound.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

// Data sent by the client when reporting a lost or found item
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ItemRequest {

    @NotBlank(message = "Title is required")
    private String title;

    private String category;

    @NotBlank(message = "Description is required")
    private String description;

    private String location;

    private LocalDateTime date; // used as lostDate or foundDate depending on the endpoint

    private String imageUrl; // returned by Cloudinary after upload
}
