package com.university.lostfound.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// A single "possible match" result returned by the AI matching feature
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MatchResponse {

    private String itemId;
    private String title;
    private double score; // 0.0 to 1.0 - how confident the match is
}
