package com.university.lostfound.service.impl;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import com.university.lostfound.exception.ApiException;
import com.university.lostfound.service.CloudinaryService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

// Handles uploading and deleting images using the Cloudinary SDK
@Service
public class CloudinaryServiceImpl implements CloudinaryService {

    @Value("${cloudinary.cloud-name}")
    private String cloudName;

    @Value("${cloudinary.api-key}")
    private String apiKey;

    @Value("${cloudinary.api-secret}")
    private String apiSecret;

    private Cloudinary getCloudinary() {
        Map<String, String> config = new HashMap<>();
        config.put("cloud_name", cloudName);
        config.put("api_key", apiKey);
        config.put("api_secret", apiSecret);
        return new Cloudinary(config);
    }

    @Override
    public String upload(MultipartFile file) {
        try {
            System.out.println("Uploading image to Cloudinary...");
            Map uploadResult = getCloudinary().uploader().upload(file.getBytes(), ObjectUtils.emptyMap());
            return uploadResult.get("secure_url").toString();
        } catch (Exception e) {
            System.out.println("Cloudinary upload failed: " + e.getMessage());
            throw new ApiException("Failed to upload image: " + e.getMessage());
        }
    }

    @Override
    public void delete(String publicId) {
        try {
            System.out.println("Deleting image from Cloudinary: " + publicId);
            getCloudinary().uploader().destroy(publicId, ObjectUtils.emptyMap());
        } catch (Exception e) {
            System.out.println("Cloudinary delete failed: " + e.getMessage());
            throw new ApiException("Failed to delete image: " + e.getMessage());
        }
    }
}
