package com.university.lostfound.service.impl;

import com.university.lostfound.exception.ResourceNotFoundException;
import com.university.lostfound.model.FoundItem;
import com.university.lostfound.repository.FoundItemRepository;
import com.university.lostfound.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

// =========================================================================
// OOP CONCEPT: POLYMORPHISM
// FoundItemService also implements ItemService, but for FoundItem.
// Even though the method signatures look identical to LostItemService,
// each class has its own independent logic and its own repository.
// =========================================================================
@Service
public class FoundItemService implements ItemService<FoundItem> {

    @Autowired
    private FoundItemRepository foundItemRepository;

    @Override
    public FoundItem save(FoundItem item) {
        System.out.println("Saving a FOUND item: " + item.getTitle());
        return foundItemRepository.save(item);
    }

    @Override
    public FoundItem findById(String id) {
        return foundItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Found item not found with id: " + id));
    }

    @Override
    public List<FoundItem> findAll() {
        return foundItemRepository.findAll();
    }

    @Override
    public void delete(String id) {
        System.out.println("Deleting found item: " + id);
        foundItemRepository.deleteById(id);
    }

    // Extra method specific to FoundItemService - not part of the shared interface
    public List<FoundItem> findFoundByUser(String userId) {
        return foundItemRepository.findByUserId(userId);
    }
}
