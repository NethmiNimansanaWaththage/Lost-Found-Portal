package com.university.lostfound.service.impl;

import com.university.lostfound.dto.MatchResponse;
import com.university.lostfound.model.FoundItem;
import com.university.lostfound.model.LostItem;
import com.university.lostfound.repository.FoundItemRepository;
import com.university.lostfound.repository.LostItemRepository;
import com.university.lostfound.service.GeminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

// =========================================================================
// This service calls the Google Gemini API for our 3 simple AI features.
// IMPORTANT: every Gemini call has a 10 second timeout and a try-catch
// fallback. If Gemini is slow or down, the app keeps working - it just
// returns an empty list / the original text instead of crashing.
// =========================================================================
@Service
public class GeminiServiceImpl implements GeminiService {

    @Value("${gemini.api.key}")
    private String apiKey;

    @Value("${gemini.api.url}")
    private String apiUrl;

    @Autowired
    private LostItemRepository lostItemRepository;

    @Autowired
    private FoundItemRepository foundItemRepository;

    private final WebClient webClient = WebClient.builder().build();

    // -------------------------------------------------------------------
    // FEATURE 1: Match Items
    // Takes a lost item, asks Gemini which found items sound similar,
    // and returns a simple list of matches with a score.
    // -------------------------------------------------------------------
    @Override
    public List<MatchResponse> findMatches(String lostItemId) {
        List<MatchResponse> matches = new ArrayList<>();

        try {
            LostItem lostItem = lostItemRepository.findById(lostItemId).orElse(null);
            if (lostItem == null) {
                return matches; // nothing to match against
            }

            List<FoundItem> foundItems = foundItemRepository.findAll();
            if (foundItems.isEmpty()) {
                return matches;
            }

            // Build a simple prompt describing the lost item and candidate found items
            StringBuilder prompt = new StringBuilder();
            prompt.append("You are a lost and found assistant. ");
            prompt.append("Find similar items based on this description: ");
            prompt.append(lostItem.getDescription());
            prompt.append(". Here are the found items (id | title | description): ");

            for (FoundItem item : foundItems) {
                prompt.append(item.getId()).append(" | ")
                        .append(item.getTitle()).append(" | ")
                        .append(item.getDescription()).append(" ; ");
            }

            prompt.append("Reply ONLY with the ids of items that could be a match, one per line.");

            String aiResponse = callGemini(prompt.toString());

            // Very simple matching: if the found item's id appears in the AI response, count it as a match
            for (FoundItem item : foundItems) {
                if (aiResponse.contains(item.getId())) {
                    matches.add(new MatchResponse(item.getId(), item.getTitle(), 0.8));
                }
            }

        } catch (Exception e) {
            System.out.println("findMatches failed, returning empty list: " + e.getMessage());
        }

        return matches;
    }

    // -------------------------------------------------------------------
    // FEATURE 2: Smart Search
    // Uses Gemini to understand the intent behind a search query and
    // matches it against found items (kept simple: checks both lost
    // and found items for relevant keywords suggested by Gemini).
    // -------------------------------------------------------------------
    @Override
    public List<MatchResponse> smartSearch(String query) {
        List<MatchResponse> results = new ArrayList<>();

        try {
            String prompt = "You are a lost and found assistant. A user is searching for: \""
                    + query + "\". List the most important keywords to search for, comma separated.";

            String aiResponse = callGemini(prompt);
            String[] keywords = aiResponse.toLowerCase().split("[,\n]");

            List<FoundItem> foundItems = foundItemRepository.findAll();
            for (FoundItem item : foundItems) {
                String text = (item.getTitle() + " " + item.getDescription()).toLowerCase();
                for (String keyword : keywords) {
                    String trimmed = keyword.trim();
                    if (!trimmed.isEmpty() && text.contains(trimmed)) {
                        results.add(new MatchResponse(item.getId(), item.getTitle(), 0.7));
                        break;
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("smartSearch failed, returning empty list: " + e.getMessage());
        }

        return results;
    }

    // -------------------------------------------------------------------
    // FEATURE 3: Description Enhancement
    // Sends a short description to Gemini and asks it to make it more
    // detailed and searchable. Falls back to the original text if Gemini fails.
    // -------------------------------------------------------------------
    @Override
    public String enhanceDescription(String description) {
        try {
            String prompt = "You are a lost and found assistant. Improve and expand this item description "
                    + "to make it more detailed and searchable, keep it under 3 sentences: " + description;

            return callGemini(prompt);

        } catch (Exception e) {
            System.out.println("enhanceDescription failed, returning original text: " + e.getMessage());
            return description; // fallback - app still works without AI
        }
    }

    // -------------------------------------------------------------------
    // Helper: makes the actual HTTP call to Gemini using WebClient.
    // Runs with a 10 second timeout via CompletableFuture so it never
    // blocks the main request thread for too long.
    // -------------------------------------------------------------------
    private String callGemini(String prompt) throws Exception {
        Map<String, Object> textPart = new HashMap<>();
        textPart.put("text", prompt);

        Map<String, Object> content = new HashMap<>();
        content.put("parts", List.of(textPart));

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("contents", List.of(content));

        String fullUrl = apiUrl + "?key=" + apiKey;

        CompletableFuture<Map> futureResponse = webClient.post()
                .uri(fullUrl)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(10))
                .toFuture();

        Map responseBody = futureResponse.get(); // wait for the result (with the 10s timeout above)
        return extractTextFromResponse(responseBody);
    }

    @SuppressWarnings("unchecked")
    private String extractTextFromResponse(Map responseBody) {
        try {
            List<Map> candidates = (List<Map>) responseBody.get("candidates");
            Map firstCandidate = candidates.get(0);
            Map content = (Map) firstCandidate.get("content");
            List<Map> parts = (List<Map>) content.get("parts");
            return (String) parts.get(0).get("text");
        } catch (Exception e) {
            System.out.println("Could not parse Gemini response: " + e.getMessage());
            return "";
        }
    }
}
