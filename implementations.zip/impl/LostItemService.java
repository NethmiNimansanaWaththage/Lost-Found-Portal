package com.university.lostfound.service.impl;

import com.university.lostfound.exception.ResourceNotFoundException;
import com.university.lostfound.model.LostItem;
import com.university.lostfound.repository.LostItemRepository;
import com.university.lostfound.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

// =========================================================================
// OOP CONCEPT: POLYMORPHISM
// LostItemService implements ItemService<LostItem>. It has its own
// version of save/findById/findAll/delete, AND it adds an extra method
// (findLostByUser) that is specific to lost items only.
// =========================================================================
@Service
public class LostItemService implements ItemService<LostItem> {

    @Autowired
    private LostItemRepository lostItemRepository;

    @Override
    public LostItem save(LostItem item) {
        System.out.println("Saving a LOST item: " + item.getTitle());
        return lostItemRepository.save(item);
    }

    @Override
    public LostItem findById(String id) {
        return lostItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Lost item not found with id: " + id));
    }

    @Override
    public List<LostItem> findAll() {
        return lostItemRepository.findAll();
    }

    @Override
    public void delete(String id) {
        System.out.println("Deleting lost item: " + id);
        lostItemRepository.deleteById(id);
    }

    // Extra method specific to LostItemService - not part of the shared interface
    public List<LostItem> findLostByUser(String userId) {
        return lostItemRepository.findByUserId(userId);
    }
}
