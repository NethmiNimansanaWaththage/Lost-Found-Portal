package com.university.lostfound.service.impl;

import com.university.lostfound.dto.ClaimRequest;
import com.university.lostfound.exception.ResourceNotFoundException;
import com.university.lostfound.model.Claim;
import com.university.lostfound.model.enums.ClaimStatus;
import com.university.lostfound.repository.ClaimRepository;
import com.university.lostfound.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ClaimServiceImpl implements ClaimService {

    @Autowired
    private ClaimRepository claimRepository;

    @Override
    public Claim createClaim(String itemId, String claimantId, ClaimRequest request) {
        Claim claim = new Claim();
        claim.setItemId(itemId);
        claim.setClaimantId(claimantId);
        claim.setMessage(request.getMessage());
        claim.setStatus(ClaimStatus.PENDING);
        claim.setDateClaimed(LocalDateTime.now());

        System.out.println("New claim created for item: " + itemId);
        return claimRepository.save(claim);
    }

    @Override
    public Claim approveClaim(String claimId) {
        Claim claim = getClaimOrThrow(claimId);
        claim.setStatus(ClaimStatus.APPROVED);
        System.out.println("Claim approved: " + claimId);
        return claimRepository.save(claim);
    }

    @Override
    public Claim rejectClaim(String claimId) {
        Claim claim = getClaimOrThrow(claimId);
        claim.setStatus(ClaimStatus.REJECTED);
        System.out.println("Claim rejected: " + claimId);
        return claimRepository.save(claim);
    }

    private Claim getClaimOrThrow(String claimId) {
        return claimRepository.findById(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found with id: " + claimId));
    }

    @Override
    public List<Claim> findAll() {
        return claimRepository.findAll();
    }

    @Override
    public List<Claim> findByItemId(String itemId) {
        return claimRepository.findByItemId(itemId);
    }

    @Override
    public List<Claim> findByClaimantId(String claimantId) {
        return claimRepository.findByClaimantId(claimantId);
    }
}
