package com.university.lostfound.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

// =========================================================================
// OOP CONCEPT: INHERITANCE
// FoundItem extends BaseItem the same way LostItem does, but adds
// foundDate and foundLocation instead.
//
// OOP CONCEPT: POLYMORPHISM
// getItemType() is overridden to return "FOUND" — a different result
// than LostItem's version, even though both share the same method
// signature inherited from BaseItem.
// =========================================================================
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Document(collection = "found_items")
public class FoundItem extends BaseItem {

    private LocalDateTime foundDate;
    private String foundLocation;

    @Override
    public String getItemType() {
        return "FOUND";
    }
}
