package com.university.lostfound.model;

import com.university.lostfound.model.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

// A registered user of the portal (student, faculty, or admin staff)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "users")
public class User {

    @Id
    private String id;

    private String name;
    private String email;
    private String password; // stored as a BCrypt hash, never plain text
    private String studentId;
    private Role role; // USER or ADMIN
    private LocalDateTime createdAt;
}
