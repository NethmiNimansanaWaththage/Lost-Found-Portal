package com.university.lostfound.model.enums;

// The two roles a user can have in the system
public enum Role {
    USER,
    ADMIN
}
