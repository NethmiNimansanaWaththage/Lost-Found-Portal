package com.university.lostfound.model.enums;

// Status of a lost or found item
public enum ItemStatus {
    ACTIVE,
    CLAIMED,
    RESOLVED
}
