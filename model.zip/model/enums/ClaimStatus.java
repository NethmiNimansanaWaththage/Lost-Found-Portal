package com.university.lostfound.model.enums;

// Status of a claim made on an item
public enum ClaimStatus {
    PENDING,
    APPROVED,
    REJECTED
}
