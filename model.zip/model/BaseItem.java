package com.university.lostfound.model;

import com.university.lostfound.model.enums.ItemStatus;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

// =========================================================================
// OOP CONCEPT: ABSTRACTION
// BaseItem is an abstract class. It defines the common shape that EVERY
// item in the system shares (lost or found), but it can never be
// instantiated on its own — only its subclasses (LostItem, FoundItem) can.
// The abstract method getItemType() forces every subclass to say what
// kind of item it is, without BaseItem needing to know the details.
// =========================================================================
@Data
@NoArgsConstructor
public abstract class BaseItem {

    @Id
    private String id;

    // OOP CONCEPT: ENCAPSULATION -> all fields are private,
    // and Lombok's @Data generates public getters/setters for controlled access.
    private String title;
    private String category;
    private String description;
    private String imageUrl;
    private String location;
    private LocalDateTime dateReported;
    private ItemStatus status;
    private String userId;

    // Abstract method - every subclass MUST implement this.
    // This is what makes BaseItem an abstraction: it declares behavior
    // without defining how it works.
    public abstract String getItemType();
}
