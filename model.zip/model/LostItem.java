package com.university.lostfound.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

// =========================================================================
// OOP CONCEPT: INHERITANCE
// LostItem extends BaseItem, meaning it inherits all the common fields
// (title, description, location, etc.) and only needs to add what makes
// a LOST item special: lostDate and lostLocation.
//
// OOP CONCEPT: POLYMORPHISM
// getItemType() is overridden here to return "LOST". When code works
// with a BaseItem reference, calling getItemType() will automatically
// run THIS version if the object is actually a LostItem.
// =========================================================================
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Document(collection = "lost_items")
public class LostItem extends BaseItem {

    private LocalDateTime lostDate;
    private String lostLocation;

    @Override
    public String getItemType() {
        return "LOST";
    }
}
