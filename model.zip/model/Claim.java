package com.university.lostfound.model;

import com.university.lostfound.model.enums.ClaimStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

// A claim made by a user saying "this found item belongs to me"
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "claims")
public class Claim {

    @Id
    private String id;

    private String itemId;
    private String claimantId;
    private String message;
    private ClaimStatus status; // PENDING, APPROVED, REJECTED
    private LocalDateTime dateClaimed;
}
