package com.university.lostfound.controller;

import com.university.lostfound.dto.MatchResponse;
import com.university.lostfound.service.GeminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

// AI-powered endpoints backed by Gemini. These are OPTIONAL features -
// if Gemini fails, these endpoints simply return empty results instead
// of breaking the app.
@RestController
@RequestMapping("/api/ai")
public class AIController {

    @Autowired
    private GeminiService geminiService;

    @GetMapping("/match/{lostItemId}")
    public ResponseEntity<List<MatchResponse>> matchItems(@PathVariable String lostItemId) {
        List<MatchResponse> matches = geminiService.findMatches(lostItemId);
        return new ResponseEntity<>(matches, HttpStatus.OK);
    }

    @GetMapping("/search")
    public ResponseEntity<List<MatchResponse>> smartSearch(@RequestParam String q) {
        List<MatchResponse> results = geminiService.smartSearch(q);
        return new ResponseEntity<>(results, HttpStatus.OK);
    }

    @PostMapping("/enhance")
    public ResponseEntity<Map<String, String>> enhanceDescription(@RequestBody Map<String, String> body) {
        String enhanced = geminiService.enhanceDescription(body.get("description"));

        Map<String, String> response = new HashMap<>();
        response.put("enhancedDescription", enhanced);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
