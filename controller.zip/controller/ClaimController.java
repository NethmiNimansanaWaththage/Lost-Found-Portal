package com.university.lostfound.controller;

import com.university.lostfound.dto.ClaimRequest;
import com.university.lostfound.model.Claim;
import com.university.lostfound.service.ClaimService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

// Endpoints for claiming found items and approving/rejecting claims
@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    // Body should include the itemId as a query param to keep this simple:
    // POST /api/claims?itemId=xyz
    @PostMapping
    public ResponseEntity<Claim> createClaim(@RequestParam String itemId,
                                              @Valid @RequestBody ClaimRequest request,
                                              Authentication authentication) {
        Claim claim = claimService.createClaim(itemId, authentication.getName(), request);
        return new ResponseEntity<>(claim, HttpStatus.CREATED);
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<Claim> approveClaim(@PathVariable String id) {
        Claim claim = claimService.approveClaim(id);
        return new ResponseEntity<>(claim, HttpStatus.OK);
    }

    @PutMapping("/{id}/reject")
    public ResponseEntity<Claim> rejectClaim(@PathVariable String id) {
        Claim claim = claimService.rejectClaim(id);
        return new ResponseEntity<>(claim, HttpStatus.OK);
    }
}
