// REPLACE: lostfound-clean/src/main/java/com/university/lostfound/controller/ClaimController.java

package com.university.lostfound.controller;

import com.university.lostfound.dto.ClaimRequest;
import com.university.lostfound.model.Claim;
import com.university.lostfound.service.ClaimService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    // Submit a new claim: POST /api/claims?itemId=xyz
    @PostMapping
    public ResponseEntity<Claim> createClaim(@RequestParam String itemId,
                                             @Valid @RequestBody ClaimRequest request,
                                             Authentication authentication) {
        Claim claim = claimService.createClaim(itemId, authentication.getName(), request);
        return new ResponseEntity<>(claim, HttpStatus.CREATED);
    }

    // Get ALL claims (admin use / owner filtering on frontend)
    @GetMapping
    public ResponseEntity<List<Claim>> getAllClaims() {
        return new ResponseEntity<>(claimService.findAll(), HttpStatus.OK);
    }

    // Get claims for a specific item
    @GetMapping("/item/{itemId}")
    public ResponseEntity<List<Claim>> getClaimsByItem(@PathVariable String itemId) {
        return new ResponseEntity<>(claimService.findByItemId(itemId), HttpStatus.OK);
    }

    // Get claims submitted BY the current user
    @GetMapping("/my")
    public ResponseEntity<List<Claim>> getMyClaims(Authentication authentication) {
        return new ResponseEntity<>(claimService.findByClaimantId(authentication.getName()), HttpStatus.OK);
    }

    // Approve a claim
    @PutMapping("/{id}/approve")
    public ResponseEntity<Claim> approveClaim(@PathVariable String id) {
        Claim claim = claimService.approveClaim(id);
        return new ResponseEntity<>(claim, HttpStatus.OK);
    }

    // Reject a claim
    @PutMapping("/{id}/reject")
    public ResponseEntity<Claim> rejectClaim(@PathVariable String id) {
        Claim claim = claimService.rejectClaim(id);
        return new ResponseEntity<>(claim, HttpStatus.OK);
    }
}
