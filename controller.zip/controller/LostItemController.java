package com.university.lostfound.controller;

import com.university.lostfound.dto.ItemRequest;
import com.university.lostfound.model.LostItem;
import com.university.lostfound.model.enums.ItemStatus;
import com.university.lostfound.service.impl.LostItemService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Endpoints for reporting and managing LOST items
@RestController
@RequestMapping("/api/lost")
public class LostItemController {

    @Autowired
    private LostItemService lostItemService;

    @PostMapping
    public ResponseEntity<LostItem> createLostItem(@Valid @RequestBody ItemRequest request,
                                                     Authentication authentication) {
        LostItem item = new LostItem();
        item.setTitle(request.getTitle());
        item.setCategory(request.getCategory());
        item.setDescription(request.getDescription());
        item.setLocation(request.getLocation());
        item.setImageUrl(request.getImageUrl());
        item.setLostDate(request.getDate());
        item.setLostLocation(request.getLocation());
        item.setStatus(ItemStatus.ACTIVE);
        item.setUserId(authentication.getName()); // email from JWT, simple version

        LostItem saved = lostItemService.save(item);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<LostItem>> getAllLostItems() {
        return new ResponseEntity<>(lostItemService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<LostItem> getLostItemById(@PathVariable String id) {
        return new ResponseEntity<>(lostItemService.findById(id), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteLostItem(@PathVariable String id) {
        lostItemService.delete(id);
        return new ResponseEntity<>("Lost item deleted successfully", HttpStatus.OK);
    }
}
