package com.university.lostfound.controller;

import com.university.lostfound.model.FoundItem;
import com.university.lostfound.model.LostItem;
import com.university.lostfound.service.impl.FoundItemService;
import com.university.lostfound.service.impl.LostItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Endpoints for fetching all items reported by a specific user
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private LostItemService lostItemService;

    @Autowired
    private FoundItemService foundItemService;

    @GetMapping("/{id}/lost")
    public ResponseEntity<List<LostItem>> getUserLostItems(@PathVariable String id) {
        return new ResponseEntity<>(lostItemService.findLostByUser(id), HttpStatus.OK);
    }

    @GetMapping("/{id}/found")
    public ResponseEntity<List<FoundItem>> getUserFoundItems(@PathVariable String id) {
        return new ResponseEntity<>(foundItemService.findFoundByUser(id), HttpStatus.OK);
    }
}
