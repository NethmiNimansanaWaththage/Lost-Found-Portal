package com.university.lostfound.controller;

import com.university.lostfound.dto.ItemRequest;
import com.university.lostfound.model.FoundItem;
import com.university.lostfound.model.enums.ItemStatus;
import com.university.lostfound.service.impl.FoundItemService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Endpoints for reporting and managing FOUND items
@RestController
@RequestMapping("/api/found")
public class FoundItemController {

    @Autowired
    private FoundItemService foundItemService;

    @PostMapping
    public ResponseEntity<FoundItem> createFoundItem(@Valid @RequestBody ItemRequest request,
                                                        Authentication authentication) {
        FoundItem item = new FoundItem();
        item.setTitle(request.getTitle());
        item.setCategory(request.getCategory());
        item.setDescription(request.getDescription());
        item.setLocation(request.getLocation());
        item.setImageUrl(request.getImageUrl());
        item.setFoundDate(request.getDate());
        item.setFoundLocation(request.getLocation());
        item.setStatus(ItemStatus.ACTIVE);
        item.setUserId(authentication.getName());

        FoundItem saved = foundItemService.save(item);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<FoundItem>> getAllFoundItems() {
        return new ResponseEntity<>(foundItemService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FoundItem> getFoundItemById(@PathVariable String id) {
        return new ResponseEntity<>(foundItemService.findById(id), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFoundItem(@PathVariable String id) {
        foundItemService.delete(id);
        return new ResponseEntity<>("Found item deleted successfully", HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FoundItem> updateFoundItem(@PathVariable String id,
                                                     @Valid @RequestBody ItemRequest request) {
        FoundItem existing = foundItemService.findById(id);
        existing.setTitle(request.getTitle());
        existing.setDescription(request.getDescription());
        existing.setCategory(request.getCategory());
        existing.setLocation(request.getLocation());
        existing.setFoundLocation(request.getLocation());
        existing.setImageUrl(request.getImageUrl() != null ? request.getImageUrl() : existing.getImageUrl());
        if (request.getDate() != null) existing.setFoundDate(request.getDate());
        FoundItem updated = foundItemService.save(existing);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }
}
